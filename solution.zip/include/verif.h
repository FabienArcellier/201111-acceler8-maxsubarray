
int CalculateMaxValue (ProblemData & data, char *borne[]);